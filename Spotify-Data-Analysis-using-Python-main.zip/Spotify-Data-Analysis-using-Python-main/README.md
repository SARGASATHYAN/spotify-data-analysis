<h1 align="center"> <a href="https://open.spotify.com/user/exll9wa5yql2llqyi1k5h56qm?si=YkkYuaD7SN60DMjXWo7eTQ&utm_source=copy-link" target="_blank"> <img src="https://github.com/mrankitgupta/Spotify-Data-Analysis-using-Python/blob/main/images/social-spotify.svg" alt="Spotify" width="55" height="40"/> </a> Spotify Data Analysis using Python <a href="https://github.com/mrankitgupta/PythonLessons" target="_blank"> <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/python/python-original.svg" alt="python" width="55" height="40"/> </a> </h1>

**I'm sharing an Exploratory Data Analysis (EDA) and Data Visualization of the data from Spotify using Python - A Data Analysis Project performed in my journey into Data Science.**

### About the Project

Spotify is a Swedish audio streaming and media services provider founded in April 2006. It is the world's largest music streaming service provider and has over 381 million monthly active users, which also includes 172 million paid subscribers.

<p align="center"> <a href="https://open.spotify.com/user/exll9wa5yql2llqyi1k5h56qm?si=YkkYuaD7SN60DMjXWo7eTQ&utm_source=copy-link" target="_blank"> <img src="https://github.com/mrankitgupta/Spotify-Data-Analysis-using-Python/blob/main/images/Spotify.webp" alt="Spotify" width="50%" height="10%"/> </a> </p>

- Here, l have explored and quantified data about music and drawn valuable insights.

- Conducted data cleaning to perform exploratory data analysis (EDA) and data visualization of the Spotify dataset using Python (Pandas, NumPy, Matplotlib and Seaborn).

- Data analysis - Exploring the relationship between the audio features of a song and how positive or negative its lyrics are, involving sentiment analysisand manyuy more.

- Spotify Data Analysis makes use of secondary data from Spotify. Use data to identify patterns and relationships between different characteristics. The activity will support in developing ability to review and interpret a dataset.

**Prerequisite:** <code>[Data Analyst Roadmap](https://github.com/mrankitgupta/Data-Analyst-Roadmap)</code> :hourglass: , <code>[Python Lessons](https://github.com/mrankitgupta/PythonLessons)</code> 📑 & <code>[Python Libraries for Data Science](https://github.com/mrankitgupta/PythonLibraries)</code> 🗂️
 
## Technologies used ⚙️

* <a href="https://github.com/mrankitgupta/Python-Lessons">Python</a> <a href="https://github.com/mrankitgupta/Python-Lessons" target="_blank"> <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/python/python-original.svg" alt="python" width="25" height="20"/> </a>

* <a href="https://github.com/mrankitgupta/Statistics-for-Data-Science-using-Python">Statistics</a><a href="https://github.com/mrankitgupta/Statistics-for-Data-Science-using-Python" target="_blank" rel="noreferrer"> <img src="https://raw.githubusercontent.com/mrankitgupta/66DaysOfData/c8c040f1c85d921db317152567f331354446286a/statistics-21.svg" alt="Statistics" width="25" height="25"/> </a>

##### Python Libraries : 
* <a href="https://github.com/mrankitgupta/Kaggle-Pandas-Solved-Exercises">Pandas</a><a href="https://github.com/mrankitgupta/Kaggle-Pandas-Solved-Exercises" target="_blank" rel="noreferrer"> <img src="https://raw.githubusercontent.com/devicons/devicon/2ae2a900d2f041da66e950e4d48052658d850630/icons/pandas/pandas-original.svg" alt="pandas" width="25" height="20"/> </a> |  <a href="https://numpy.org/">NumPy</a><a href="https://numpy.org/" target="_blank" rel="noreferrer"> <img src="https://raw.githubusercontent.com/mrankitgupta/mrankitgupta/2a582d085b324cff4917325112229027309ecae3/Numpy-logo.svg" alt="numpy" width="25" height="20"/> </a> |  <a href="https://matplotlib.org/">Matplotlib</a><a href="https://matplotlib.org/" target="_blank" rel="noreferrer"> <img src="https://raw.githubusercontent.com/mrankitgupta/mrankitgupta/1331979c3208a15be2c2a6177ffc38ced3d6b434/Matplotlib_icon.svg" alt="matplotlib" width="25" height="20"/> </a> |  <a href="https://seaborn.pydata.org">Seaborn</a><a href="https://seaborn.pydata.org" target="_blank" rel="noreferrer"> <img src="https://seaborn.pydata.org/_images/logo-mark-lightbg.svg" alt="Seaborn" width="25" height="20"/> </a> 


<h2 align="left">Certifications 📜 🎓 ✔️</h2>

- [Data Analysis with Python](https://github.com/mrankitgupta) - by IBM
 
- [Data Visualization with Python](https://github.com/mrankitgupta) - by IBM

- [Pandas](https://www.kaggle.com/learn/certification/mrankitgupta/pandas) - by Kaggle
 
- [Numpy](https://olympus1.mygreatlearning.com/course_certificate/IQVNJSIN) & [Matplotlib](https://olympus1.mygreatlearning.com/course_certificate/RNVTUIMW) - by Great Learning 

- [Databases and SQL for Data Science with Python](https://github.com/mrankitgupta) - by IBM

- [Statistics for Data Science with Python](https://www.credly.com/badges/354576a0-b672-4245-8cad-82dc3f3df76f/public_url) - by IBM


## Project - Spotify Data Analysis using Python

**[Kaggle Project: Spotify Data Analysis](https://www.kaggle.com/code/mrankitgupta/spotify-data-analysis-using-python)**  <a href="https://www.kaggle.com/code/mrankitgupta/spotify-data-analysis-using-python" target="_blank"> <img src="https://github.com/mrankitgupta/Spotify-Data-Analysis-using-Python/blob/main/images/social-spotify.svg" alt="Spotify" width="35" height="20"/> 🔗
 
[Kaggle Spotify Datasets:](https://www.kaggle.com/code/mrankitgupta/spotify-data-analysis-using-python-project/data) <code>[Spotify Tracks](https://www.kaggle.com/code/mrankitgupta/spotify-data-analysis-using-python/data?select=tracks.csv)</code> & <code>[Spotify Features](https://www.kaggle.com/code/mrankitgupta/spotify-data-analysis-using-python/data?select=SpotifyFeatures.csv)</code>  

### Objective
 
1. **Top 10 most popular songs on Spotify**

2. **Top 10 least popular songs on Spotify**
 
3. **Correlation Heatmap between Variable**
  <p align="center"> <a href="https://www.kaggle.com/code/mrankitgupta/spotify-data-analysis-using-python" target="_blank"> <img src="https://github.com/mrankitgupta/Spotify-Data-Analysis-using-Python/blob/main/images/Correlation%20Heatmap%20between%20Variable.png" alt="Spotify Data Analysis using Python" width="80%" height="80%"/> </a> </p>
 
4. **Regression plot - Correlation between Loudness and Energy**
  <p align="center"> <a href="https://www.kaggle.com/code/mrankitgupta/spotify-data-analysis-using-python" target="_blank"> <img src="https://github.com/mrankitgupta/Spotify-Data-Analysis-using-Python/blob/main/images/Regression%20plot%20-%20Correlation%20between%20Loudness%20and%20Energy.png" alt="Spotify Data Analysis using Python" width="80%" height="80%"/> </a> </p>
 
5. **Regression plot - Correlation between Popularity and Acousticness**
 <p align="center"> <a href="https://www.kaggle.com/code/mrankitgupta/spotify-data-analysis-using-python" target="_blank"> <img src="https://github.com/mrankitgupta/Spotify-Data-Analysis-using-Python/blob/main/images/Regression%20plot%20-%20Correlation%20between%20Popularity%20and%20Acousticness.png" alt="Spotify Data Analysis using Python" width="80%" height="80%"/> </a> </p>
 
6. **Distibution plot - Visualize total number of songs on Spotify since 1992**
 <p align="center"> <a href="https://www.kaggle.com/code/mrankitgupta/spotify-data-analysis-using-python" target="_blank"> <img src="https://github.com/mrankitgupta/Spotify-Data-Analysis-using-Python/blob/main/images/Distibution%20plot%20-%20Visualize%20total%20number%20of%20songs%20on%20Spotify%20since%201992.png" alt="Spotify Data Analysis using Python" width="80%" height="80%"/> </a> </p>
 
7. **Change in Duration of songs wrt Years**
 <p align="center"> <a href="https://www.kaggle.com/code/mrankitgupta/spotify-data-analysis-using-python" target="_blank"> <img src="https://github.com/mrankitgupta/Spotify-Data-Analysis-using-Python/blob/main/images/Change%20in%20Duration%20of%20songs%20wrt%20Years.png" alt="Spotify Data Analysis using Python" width="80%" height="80%"/> </a> </p>
 
8. **Duration of songs in different Genres**
 <p align="center"> <a href="https://www.kaggle.com/code/mrankitgupta/spotify-data-analysis-using-python" target="_blank"> <img src="https://github.com/mrankitgupta/Spotify-Data-Analysis-using-Python/blob/main/images/Duration%20of%20songs%20in%20different%20Genres.png" width="80%" height="80%"/> </a> </p>
 
9. **Top 5 Genres by Popularity**
 <p align="center"> <a href="https://www.kaggle.com/code/mrankitgupta/spotify-data-analysis-using-python" target="_blank"> <img src="https://github.com/mrankitgupta/Spotify-Data-Analysis-using-Python/blob/main/images/Top%205%20Genres%20by%20Popularity.png" width="80%" height="80%"/> </a> </p>
 

## Related Projects:question: 👨‍💻 🛰️

<code>[Data Analyst Roadmap](https://github.com/mrankitgupta/Data-Analyst-Roadmap)</code> :hourglass: 

<code>[Sales Insights - Data Analysis using Tableau & SQL](https://github.com/mrankitgupta/Sales-Insights-Data-Analysis-using-Tableau-and-SQL)</code> 📊

<code>[Statistics for Data Science using Python](https://github.com/mrankitgupta/Statistics-for-Data-Science-using-Python)</code> 📊
 
<code>[Kaggle - Pandas Solved Exercises](https://github.com/mrankitgupta/Kaggle-Pandas-Solved-Exercises)</code> 📊
 
<code>[Python Lessons](https://github.com/mrankitgupta/PythonLessons)</code> 📑
 
<code>[Python Libraries for Data Science](https://github.com/mrankitgupta/PythonLibraries)</code> 🗂️

### Liked my Contributions:question:[Follow Me](https://github.com/mrankitgupta/):point_right: [Nominate Me for GitHub Stars](https://stars.github.com/nominate/) :star: :sparkles:

## For any queries/doubts 🔗 👇 

### [Ankit Gupta](https://ankitgupta.bio.link/)
<p align="left"> <a href="https://twitter.com/MrAnkitGupta_/" target="blank"><img src="https://img.shields.io/twitter/follow/MrAnkitGupta_?logo=twitter&style=for-the-badge" alt="MrAnkitGupta_" /></a> </p>

<a href="mailto:ankitgupta3150@gmail.com" target="blank"><img align="center" src="https://img.shields.io/badge/Gmail-D14836?style=for-the-badge&logo=gmail&logoColor=white" alt="ankitgupta3150@gmail.com" height="20" width="85" /></a>
<a href="https://www.linkedin.com/in/mrankitgupta" target="blank"><img align="center" src="https://img.shields.io/badge/-MrAnkitGupta-blue?style=flat-square&logo=Linkedin&logoColor=white&link=https://www.linkedin.com/in/mrankitgupta/" alt="MrAnkitGupta" height="20" width="100" /></a>
<a href="https://www.instagram.com/MrAnkitGupta_" target="blank"><img align="center" src="https://img.shields.io/badge/-@MrAnkitGupta_-D7008A?style=flat-square&labelColor=D7008A&logo=Instagram&logoColor=white&link=https://www.instagram.com/MrAnkitGupta_" alt="MrAnkitGupta_" height="20" width="110" /></a>
<a href="https://ankitgupta.bio.link/" target="blank"><img align="center" src="https://img.shields.io/badge/website-000000?style=for-the-badge&logo=About.me&logoColor=white&link=https://ankitgupta.bio.link/" alt="AnkitGupta" height="20" width="90" /></a>
<a href="https://github.com/mrankitgupta/" target="blank"><img align="center" src="https://img.shields.io/github/followers/mrankitgupta?label=Follow&style=social&link=https://github.com/mrankitgupta/" alt="MrAnkitGupta" height="20" width="90" /></a>

  
